﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace ExamenFinal
{
    public  class ControlMateria
    {
        Conex mod = new Conex();
        InfoMateria estuu = new InfoMateria();
        string sql;

        public DataTable leer()
        {
            sql = "select "
                + "id_materia,"
                + "nombre,"

                + "id_profesor"
                + " from "
                + "materia";
            return mod.llenarDT(sql);
        }

        public DataTable buscar(int id)
        {
            sql = "select "
                + "id_materia,"
                + "nombre,"

                + "id_profesor"
                + " from "
                + "materia"
                + " where "
                + "id_materia = " + id;
            return mod.llenarDT(sql);
        }

        public void insertar(InfoMateria estuu)
        {
            sql = "insert into materia ("
                + "id_materia,"
                + "nombre,"

                + "id_profesor"
                + ") values ("
                + estuu.Id_materia + ","
                + "'" + estuu.Nombre + "',"
               
                + "'" + estuu.Id_profesor + "'" +
                ")";
            mod.ejecutarSQL(sql);
        }

        public void modificar(InfoMateria estuu)
        {
            sql = "update materia set "
                + "nombre ='" + estuu.Nombre + "',"
                
                + "id_profesor = '" + estuu.Id_profesor  +"'"
                + " where "
                + "id_materia = " + estuu.Id_materia;

            mod.ejecutarSQL(sql);
        }

        public void eliminar(int id)
        {
            sql = "delete from materia "
                + "where "
                + "id_materia = " + id;
            mod.ejecutarSQL(sql);
        }
    }
}

