﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
            
        }

        private void estudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Estudiante estu = new Estudiante();
            estu.MdiParent = this;
            estu.Show();
        }

        private void materiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Materia mate = new Materia();
            mate.MdiParent = this;
            mate.Show();
        }

        private void profesorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Profesor pro = new Profesor();
            pro.MdiParent = this;
            pro.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }
    }
}
