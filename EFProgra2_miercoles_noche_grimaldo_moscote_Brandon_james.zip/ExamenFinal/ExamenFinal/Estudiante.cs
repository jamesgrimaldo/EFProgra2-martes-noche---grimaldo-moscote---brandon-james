﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace ExamenFinal
{
    public partial class Estudiante : Form
    {
        ControlEstudiante controlestudiante = new ControlEstudiante();
       InfoEstudiante entidadestu = new InfoEstudiante();
        ControlMateria tt = new ControlMateria();
        public Estudiante()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Estudiante_Load(object sender, EventArgs e)
        {
            cargarGrid();
            cargarGrid2();
            
        }
        private void cargarGrid()
        {
            dataGridView1.DataSource = controlestudiante.leer();
            
        }
        private void cargarGrid2()
        {
            for (int i = 0; i < tt.leer().Rows.Count; i++)
            {
                txtMateria.Items.Add(tt.leer().Rows[i][1].ToString());

            }
            txtMateria.SelectedIndex = 0; 
        }
        private void cargarEntidad()
        {
            entidadestu.Id_estudiante = Convert.ToInt32(txtEstudiante.Text);
            entidadestu.Nombre = txtNombre.Text;
            entidadestu.Apellido = txtApellido.Text;
            entidadestu.Direccion = txtDireccion.Text;
            entidadestu.Edad = Convert.ToInt32(txtEdad.Text);
            entidadestu.Id_materia = Convert.ToInt32(txtMateria.Text);
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtEstudiante.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtMateria.Text = "";
            txtEdad.Text = "";
            txtDireccion.Text = "";
            txtMateria.Text = "";



        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            cargarEntidad();
            controlestudiante.insertar(entidadestu);
            cargarGrid();
            limpiarCampos();
       
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = controlestudiante.buscar(Convert.ToInt16(txtEstudiante.Text));
            txtNombre.Text = dt.Rows[0][1].ToString();
           txtApellido.Text = dt.Rows[0][2].ToString();
            txtDireccion.Text = dt.Rows[0][3].ToString();
            txtEdad.Text = dt.Rows[0][4].ToString();
           txtMateria.Text = dt.Rows[0][5].ToString();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            controlestudiante.eliminar(Convert.ToInt16(txtEstudiante.Text));
            cargarGrid();
            limpiarCampos();
        }
        private void limpiarCampos()
        {
            txtEstudiante.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtMateria.Text = "";
            txtEdad.Text = "";
            txtDireccion.Text = "";
            txtMateria.Text = "";
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            cargarEntidad();
            controlestudiante.modificar(entidadestu);
            cargarGrid();
            limpiarCampos();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            cargarGrid();
        } 
    }
}
