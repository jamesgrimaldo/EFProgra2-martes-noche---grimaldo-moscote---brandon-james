﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinal
{      
   
    public partial class Materia : Form
    {  ControlMateria control = new ControlMateria();
       InfoMateria entidadestu = new InfoMateria();
        ControlProfesor tt = new ControlProfesor();
        public Materia()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Materia_Load(object sender, EventArgs e)
        {
            cargarGrid();
            cargarGrid2();
        }
        private void cargarGrid()
        {
            dataGridView1.DataSource = control.leer();
        }
        private void cargarGrid2()
        {
            for (int i = 0; i < tt.leer().Rows.Count; i++)
            {
                txtProfesor.Items.Add(tt.leer().Rows[i][1].ToString());

            }
            txtProfesor.SelectedIndex = 0;
        }
        private void cargarEntidad()
        {
            entidadestu.Id_materia = Convert.ToInt32(txtMateria.Text);
            entidadestu.Nombre = txtNombre.Text;
            
            entidadestu.Id_profesor = Convert.ToInt32(txtProfesor.Text);
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            cargarGrid(); 
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            control.eliminar(Convert.ToInt16(txtMateria.Text));
            cargarGrid();
            limpiarCampos();
        }
        private void limpiarCampos()
        {
            txtMateria.Text = "";
            txtNombre.Text = "";
           txtProfesor.Text = "";
            
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            cargarEntidad();
            control.insertar(entidadestu);
            cargarGrid();
            limpiarCampos();
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = control.buscar(Convert.ToInt16(txtMateria.Text));
            txtNombre.Text = dt.Rows[0][1].ToString();
            txtProfesor.Text = dt.Rows[0][2].ToString();
            
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            cargarEntidad();
            control.modificar(entidadestu);
            cargarGrid();
            limpiarCampos();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {

        }
    }
}
