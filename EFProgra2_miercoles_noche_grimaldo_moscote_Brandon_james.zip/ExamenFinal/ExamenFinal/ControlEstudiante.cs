﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace ExamenFinal
{
    class ControlEstudiante
    {
        Conex mod = new Conex();
        InfoEstudiante estu = new InfoEstudiante();
        string sql;

        public DataTable leer()
        {
            sql = "select "
                + "id_estudiante,"
                + "nombre,"
                + "apellido,"
                + "direccion,"
                + "edad,"
                + "id_materia"
                + " from "
                + "estudiante";
            return mod.llenarDT(sql);
        }

        public DataTable buscar(int id)
        {
            sql = "select "
                + "id_estudiante,"
                + "nombre,"
                + "apellido,"
                + "direccion,"
                + "edad,"
                + "id_materia"
                + " from "
                + "estudiante"
                + " where "
                + "id_estudiante = " + id;
            return mod.llenarDT(sql);
        }

        public void insertar(InfoEstudiante estu)
        {
            sql = "insert into estudiante ("
                + "id_estudiante,"
                + "nombre,"
                + "apellido,"
                + "direccion,"
                + "edad,"
                + "id_materia"
                + ") values ("
                + estu.Id_estudiante + ","
                + "'" + estu.Nombre + "',"
                + "'" + estu.Apellido + "',"
                + "'" + estu.Direccion + "',"
                + "'" + estu.Edad + "',"
                + "'" + estu.Id_materia + "'" +
                ")";
            mod.ejecutarSQL(sql);
        }

        public void modificar(InfoEstudiante estu)
        {
            sql = "update estudiante set "
                + "nombre ='" + estu.Nombre + "',"
                + "apellido = '" + estu.Apellido + "',"
                + "direccion = '" + estu.Direccion + "',"
                + "edad = '" + estu.Edad + "',"
                + "id_materia = '" + estu.Id_materia + "'"
                + " where "
                + "id_estudiante = " + estu.Id_estudiante;
            
            mod.ejecutarSQL(sql);
        }

        public void eliminar(int id)
        {
            sql = "delete from estudiante "
                + "where "
                + "id_estudiante = " + id;
            mod.ejecutarSQL(sql);
        }
    }
}
