﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Threading;

namespace ExamenFinal
{
    //    static class Program
    //    {
    //        /// <summary>
    //        /// The main entry point for the application.
    //        /// </summary>        
    //        static Form1 frm1;
    //        [STAThread]

    //        static void Main(string[] args)
    //        {
    //            Application.EnableVisualStyles();
    //            Application.SetCompatibleTextRenderingDefault(false);
    //            Thread thrd1 = new Thread(ConsoleInputThreadProc);
    //            frm1 = new Form1();
    //            thrd1.Start(frm1);
    //            Application.Run(frm1);

    //        }
    //        static void ConsoleInputThreadProc(object state)
    //        {
    //            Console.WriteLine("no me funciona el abrir consola aqui en mis visual 2014 no se si es un error de verciones");
    //            Console.ReadKey();
    //        }
    //    }
    //}
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}