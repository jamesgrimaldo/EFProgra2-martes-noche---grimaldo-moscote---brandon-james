﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace ExamenFinal
{
    class ControlProfesor
    {
        Conex mod = new Conex();
        InfoProfesor est = new InfoProfesor();
        string sql;

        public DataTable leer()
        {
            sql = "select "
                + "id_profesor,"
                + "nombre,"

                + "apellido"
                + " from "
                + "profesor";
            return mod.llenarDT(sql);
        }

        public DataTable buscar(int id)
        {
            sql = "select "
                + "id_profesor,"
                + "nombre,"

                + "apellido"
                + " from "
                + "profesor"
                + " where "
                + "id_profesor = " + id;
            return mod.llenarDT(sql);
        }

        public void insertar(InfoProfesor est)
        {
            sql = "insert into materia ("
                + "id_profesor,"
                + "nombre,"

                + "apellido"
                + ") values ("
                + est.Id_profesor + ","
                + "'" + est.Nombre + "',"

                + "'" + est.Apellido + "'" +
                ")";
            mod.ejecutarSQL(sql);
        }

        public void modificar(InfoProfesor est)
        {
            sql = "update profesor set "
                + "nombre ='" + est.Nombre + "',"

                + "apellido = '" + est.Apellido + "'"
                + " where "
                + "id_profesor = " + est.Id_profesor;

            mod.ejecutarSQL(sql);
        }

        public void eliminar(int id)
        {
            sql = "delete from profesor "
                + "where "
                + "id_profesor = " + id;
            mod.ejecutarSQL(sql);
        }
    }
}

