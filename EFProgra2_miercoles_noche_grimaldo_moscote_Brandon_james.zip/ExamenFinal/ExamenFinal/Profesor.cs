﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinal
{
    public partial class Profesor : Form
    {
        ControlProfesor con = new ControlProfesor();
        InfoProfesor en = new InfoProfesor();
        public Profesor()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Profesor_Load(object sender, EventArgs e)
        {
            cargarGrid();
        }
        private void cargarGrid()
        {
            dataGridView1.DataSource = con.leer();
        }
        private void cargarEntidad()
        {
            en.Id_profesor = Convert.ToInt32(txtProfesor.Text);
            en.Nombre = txtNombre.Text;

            en.Apellido = txtApellido.Text;
        }
        private void limpiarCampos()
        {
            txtApellido.Text = "";
            txtNombre.Text = "";
            txtProfesor.Text = "";

        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            cargarGrid();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            con.eliminar(Convert.ToInt16(txtProfesor.Text));
            cargarGrid();
            limpiarCampos();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            cargarEntidad();
            con.insertar(en);
            cargarGrid();
            limpiarCampos();
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = con.buscar(Convert.ToInt16(txtProfesor.Text));
            txtNombre.Text = dt.Rows[0][1].ToString();
            txtApellido.Text = dt.Rows[0][2].ToString();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            cargarEntidad();
            con.modificar(en);
            cargarGrid();
            limpiarCampos();
        }
    }
}
