﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parte2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("gererar");
            Console.WriteLine("cantidad de estidiantes menores y mayores");
            ModuloEstadistica edades = new ModuloEstadistica();
            Console.Write(edades.calcularEdades());
            Console.ReadKey();
        }
    }
}
