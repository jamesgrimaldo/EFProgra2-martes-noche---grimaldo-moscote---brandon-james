﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
 namespace Parte2
{
    class ModuloEstadistica
    {
        private int menores = 0;
        private int mayores = 0;
        public string calcularEdades()
        {
        string sql;
        string conexion = "Data Source=JAMES/SQLEXPRESS;" +
                          "Initial Catalog=bd_colegio;" +
                          "Integrated Security=True;"; 

        DataTable dt = new DataTable();
        sql = "select "
                + "id_estudiante,"
                + "nombre,"
                + "apellido,"
                + "direccion,"
                + "edad,"
                + "id_materia"
                + " from "
                + "estudiante";
            SqlConnection sqlconn = new SqlConnection(conexion);
        sqlconn.Open();
        SqlDataAdapter sqlda = new SqlDataAdapter(sql, sqlconn);
        sqlda.Fill(dt);
        sqlconn.Close();
            for (int i = 0; i < dt.Rows.Count; i++)
                      {

                            if(  int.Parse(dt.Rows[i][4].ToString()) < 18  )
                              {
                    menores += 1;
                              }
                else { mayores += 1; }
                         

                      }
                
            return "menores: " + menores.ToString() + " mayores: " +mayores.ToString()  ;

        }
    }
}
